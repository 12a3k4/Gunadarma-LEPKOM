package main

import (
	"fmt"
	"log"
	"net/http"
)

func main(){
	port := 8080 //ubah 2 digit terakhir npm 

	http.Handle("/", http.FileServer(http.Dir("polymer_57419400")))
	fmt.Println("Sheila Syaninka") // ubah nama masing-masing
	fmt.Printf("Server berjalan pada port %d", port)
	log.Fatal(http.ListenAndServe(fmt.Sprintf(":%d", port), nil))
}