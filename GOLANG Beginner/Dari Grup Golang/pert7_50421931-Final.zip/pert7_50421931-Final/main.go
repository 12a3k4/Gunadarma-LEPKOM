package main

import (
	"log"
	"net/http"
	"os"
	"path/filepath"
	"strings"
)

type spaHandler struct {
	staticPath string
	indexPath  string
}

func (h spaHandler) ServeHTTP(w http.ResponseWriter, r *http.Request) {
	path := filepath.Join(h.staticPath, r.URL.Path)

	_, err := os.Stat(path)
	if os.IsNotExist(err) {
		if strings.Contains(path, "src") {
			http.ServeFile(w, r, filepath.Join(h.staticPath, "my-view404.html"))
		}
		http.ServeFile(w, r, filepath.Join(h.staticPath, h.indexPath))
		return
	} else if err != nil {
		http.Error(w, err.Error(), http.StatusInternalServerError)
		return
	}
	http.FileServer(http.Dir(h.staticPath)).ServeHTTP(w, r)

}

func main() {
	spa := spaHandler{staticPath: "polymer", indexPath: "index.html"}
	http.Handle("/", spa)
	log.Print("Server berjalan di http://localhost:8031")
	log.Fatal(http.ListenAndServe(":8031", nil))
}
